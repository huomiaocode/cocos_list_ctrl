"use strict";
cc._RF.push(module, '280c3rsZJJKnZ9RqbALVwtK', 'test');
// Script/test.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        list: require("cocos_list_ctrl")

    },

    onLoad: function onLoad() {
        var datas = [];

        for (var i = 0; i < 1000; i++) {
            datas.push({
                label: "label" + i
            });
        }

        this.list.setItemInitParams(this._onListItemClicked.bind(this));

        this.list.setDataProvider(datas);
    },

    _onListItemClicked: function _onListItemClicked(itemData) {
        console.log(itemData);
    }
});

cc._RF.pop();