(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/list_item.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '2c0f6bB9shOmrB86TF1gk8j', 'list_item', __filename);
// Script/list_item.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        txt: cc.Label
    },

    init: function init(callback) {
        this._callback = callback;
    },

    updateItem: function updateItem(data, index) {
        if (!data) return;

        this._data = data;
        this._index = index;

        this.txt.string = data.label + " " + index;
    },

    onBtnClick: function onBtnClick() {
        this._callback && this._callback(this._data);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=list_item.js.map
        