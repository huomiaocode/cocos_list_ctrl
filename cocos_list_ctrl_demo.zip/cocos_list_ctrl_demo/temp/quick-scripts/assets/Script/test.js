(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/test.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '280c3rsZJJKnZ9RqbALVwtK', 'test', __filename);
// Script/test.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        list: require("cocos_list_ctrl")

    },

    onLoad: function onLoad() {
        var datas = [];

        for (var i = 0; i < 1000; i++) {
            datas.push({
                label: "label" + i
            });
        }

        this.list.setItemInitParams(this._onListItemClicked.bind(this));

        this.list.setDataProvider(datas);
    },

    _onListItemClicked: function _onListItemClicked(itemData) {
        console.log(itemData);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=test.js.map
        